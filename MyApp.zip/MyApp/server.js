// server.js — Node.js server using static HTML with profile pic upload & messaging

const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();

const db = new sqlite3.Database('./database/app.db');

// Multer setup for profile picture upload
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({
  secret: 'secret',
  resave: false,
  saveUninitialized: false
}));

// Ensure tables exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    profile_pic TEXT DEFAULT 'default.png'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    message TEXT,
    timestamp TEXT
  )`);
});

// Routes — HTML pages
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views', 'index.html')));
app.get('/home', (req, res) => {
  if (!req.session.user) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'views', 'home.html'));
});
app.get('/message', (req, res) => {
  if (!req.session.user) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'views', 'message.html'));
});

// API route to fetch messages
app.get('/api/messages', (req, res) => {
  if (!req.session.user) return res.status(403).json({ error: 'Unauthorized' });

  db.all(`
    SELECT messages.*, users.profile_pic 
    FROM messages 
    JOIN users ON messages.username = users.username 
    ORDER BY messages.id DESC
  `, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Registration route
app.post('/register', upload.single('profile_pic'), (req, res) => {
  const { username, password } = req.body;
  const profilePic = req.file ? req.file.filename : 'default.png';

  db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
    if (row) return res.send('Username already exists');

    db.run('INSERT INTO users (username, password, profile_pic) VALUES (?, ?, ?)',
      [username, password, profilePic], err => {
        if (err) return res.send('Error creating user');
        res.redirect('/');
      });
  });
});

// Login route
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, user) => {
    if (!user) return res.send('Invalid credentials');
    req.session.user = user;
    res.redirect('/home');
  });
});

// Send message route
app.post('/send-message', (req, res) => {
  if (!req.session.user) return res.redirect('/');

  const username = req.session.user.username;
  const message = req.body.message;
  const timestamp = new Date().toLocaleString('en-US', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: 'numeric', minute: '2-digit', hour12: true
  }).replace(',', ' -');

  db.run('INSERT INTO messages (username, message, timestamp) VALUES (?, ?, ?)',
    [username, message, timestamp], err => {
      if (err) return res.send('Error saving message');
      res.redirect('/message');
    });
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Start server with the link
app.listen(3000, () => console.log('Server running at http://localhost:3000'));
