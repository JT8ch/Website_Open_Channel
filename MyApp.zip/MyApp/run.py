import sys
import datetime

def log_message(msg, user):
    # This is just to prove it's running. You can later write this to a file if needed.
    print(f"[{datetime.datetime.now()}] {user} sent: {msg}")

if __name__ == "__main__":
    if len(sys.argv) >= 3:
        message = sys.argv[1]
        username = sys.argv[2]
        log_message(message, username)
    else:
        print("Not enough arguments.")
