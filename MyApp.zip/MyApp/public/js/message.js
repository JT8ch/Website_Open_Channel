document.addEventListener('DOMContentLoaded', () => {
  fetch('/api/messages')
    .then(res => res.json())
    .then(messages => {
      const container = document.getElementById('messages');
      messages.forEach(msg => {
        const div = document.createElement('div');
        div.className = 'message-item';
        div.innerHTML = `
          <div class="message-profile">
            <div class="blob-container small-blob">
              <img src="/uploads/${msg.profile_pic || 'default.png'}" alt="Profile">
            </div>
          </div>
          <div class="message-content">
            <strong>${msg.username}</strong>
            <span class="timestamp">@ ${msg.timestamp}</span>
            <p>${msg.message}</p>
          </div>
        `;
        container.appendChild(div);
      });
    })
    .catch(err => {
      console.error('Failed to load messages:', err);
    });
});
